@echo off
:: Otimizador 2026 - Manutencao Completa e Profunda do PC
:: Versao aprimorada com limpezas avancadas e otimizacoes de sistema

setlocal enabledelayedexpansion

:: Pedir permissao de administrador se nao estiver rodando como admin
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' neq '0' (
    echo.
    echo Este script requer permissoes de administrador!
    echo Solicitando acesso...
    echo.
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    set params = %*:"="
    echo UAC.ShellExecute "cmd.exe", "/c cd /d ""%cd%"" && ""%~s0"" %params%", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
cls
echo.
echo ===================================================================
echo           OTIMIZADOR 2026 - MANUTENCAO COMPLETA DO PC
echo ===================================================================
echo.
echo Iniciando manutencao profunda do sistema...
echo.

echo [1/12] Atualizando Provedor de Pacotes...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Install-PackageProvider NuGet -Force -ErrorAction SilentlyContinue" 2>nul
echo Provedor atualizado
echo.

echo [2/12] Atualizando Fontes de Aplicativos...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "winget source update" 2>nul
echo Fontes atualizadas
echo.

echo [3/12] Procurando Atualizacoes de Aplicativos...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "winget upgrade --all --include-unknown --accept-source-agreements --accept-package-agreements" 2>nul
echo Aplicativos atualizados
echo.

echo [4/12] Atualizando Windows e Drivers...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Install-Module PSWindowsUpdate -Force -AllowClobber -ErrorAction SilentlyContinue" 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "Import-Module PSWindowsUpdate -ErrorAction SilentlyContinue; Add-WUServiceManager -MicrosoftUpdate -Confirm:$false -ErrorAction SilentlyContinue; Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -ErrorAction SilentlyContinue" 2>nul
echo Windows Update e drivers instalados
echo.

echo [5/12] Verificando Saude da Imagem do Windows...
echo -------------------------------------------------------
DISM /Online /Cleanup-Image /ScanHealth
echo.

echo [6/12] Reparando Imagem do Windows...
echo -------------------------------------------------------
DISM /Online /Cleanup-Image /RestoreHealth
echo.

echo [7/12] Verificando Integridade dos Arquivos do Sistema...
echo -------------------------------------------------------
sfc /scannow
echo.

echo [8/12] Verificando Disco e Setores Ruins...
echo -------------------------------------------------------
chkdsk C: /scan
echo.

echo [9/12] Atualizando Assinaturas de Antivirus e Verificando Ameacas...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Update-MpSignature -ErrorAction SilentlyContinue" 2>nul
echo Assinaturas atualizadas
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-MpScan -ScanType QuickScan -ErrorAction SilentlyContinue" 2>nul
echo Verificacao rapida concluida
echo.

echo [10/12] Limpando Arquivos Temporarios e Cache...
echo -------------------------------------------------------
echo Limpando TEMP...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item '$env:TEMP\*' -Recurse -Force -ErrorAction SilentlyContinue" 2>nul
echo Limpando Windows\Temp...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item 'C:\Windows\Temp\*' -Recurse -Force -ErrorAction SilentlyContinue" 2>nul
echo Limpando Prefetch...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item 'C:\Windows\Prefetch\*' -Recurse -Force -ErrorAction SilentlyContinue" 2>nul
echo Limpando SoftwareDistribution...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item 'C:\Windows\SoftwareDistribution\Download\*' -Recurse -Force -ErrorAction SilentlyContinue" 2>nul
echo Limpando Cache DNS...
ipconfig /flushdns >nul
echo Limpando Cache de Aplicativos...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item 'C:\Users\*\AppData\Local\Temp\*' -Recurse -Force -ErrorAction SilentlyContinue" 2>nul
echo Arquivos temporarios limpos
echo.

echo [11/12] Limpando Cache de Atualizacoes Antigas...
echo -------------------------------------------------------
DISM /Online /Cleanup-Image /StartComponentCleanup
echo.
DISM /Online /Cleanup-Image /StartComponentCleanup /ResetBase
echo Cache de componentes limpo
echo.

echo [12/12] Esvaziando Lixeira...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Clear-RecycleBin -Force -ErrorAction SilentlyContinue" 2>nul
echo Lixeira esvaziada
echo.

echo.
echo ===================================================================
echo             MANUTENCAO FINALIZADA COM SUCESSO
echo ===================================================================
echo.
echo Otimizacoes Realizadas:
echo - Windows Update e drivers atualizados
echo - Imagem do Windows verificada e reparada
echo - Sistema de arquivos verificado
echo - Disco verificado para setores ruins
echo - Antivirus atualizado e verificacao realizada
echo - Cache e arquivos temporarios limpos
echo - DNS e cache de rede limpos
echo - Componentes do Windows otimizados
echo - Lixeira esvaziada
echo.
echo RECOMENDACAO: Reinicie o computador agora para aplicar todas as mudancas!
echo.
echo ===================================================================
echo.
pause
