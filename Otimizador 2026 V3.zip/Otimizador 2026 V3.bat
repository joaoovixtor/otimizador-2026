@echo off
:: ===================================================================
:: Otimizador 2026 V3 - Manutencao, Otimizacao e Diagnostico do PC
:: Versao V3: Alta performance, execucao assincrona de logs,
:: otimizacoes de rede, limpeza profunda e diagnostico de estabilidade.
:: ===================================================================

setlocal enabledelayedexpansion

:: -------------------------------------------------------------
:: Elevacao Automatica de Privilegios (Administrador)
:: -------------------------------------------------------------
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' neq '0' (
    echo.
    echo [!] Solicitando permissoes de Administrador...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "cmd.exe", "/c cd /d ""%~dp0"" && ""%~s0"" %*", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
cd /d "%~dp0"

:: -------------------------------------------------------------
:: Configuracao do Ambiente e Logs Profissionais
:: -------------------------------------------------------------
set "LOGDIR=%~dp0Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set "DT=%%I"
if not defined DT (
    for /f "delims=" %%A in ('powershell -NoProfile -Command "Get-Date -Format 'yyyyMMdd_HHmmss'"') do set "DT=%%A"
)
set "LOGFILE=%LOGDIR%\Otimizador_V3_%DT%.log"

set /a OK_COUNT=0
set /a FAIL_COUNT=0
set /a SKIP_COUNT=0

call :log "===================================================================="
call :log "  OTIMIZADOR 2026 V3 - INICIO DA MANUTENCAO: %date% %time%"
call :log "===================================================================="

cls
echo ===================================================================
echo           OTIMIZADOR 2026 V3 - ULTIMATE PC PERFORMANCE
echo ===================================================================
echo.
echo Log de Execucao: %LOGFILE%
echo.
echo Pressione qualquer tecla para iniciar a otimizacao completa...
echo.
pause >nul

:: ===================================================================
echo.
echo [1/14] Otimizando Infraestrutura de Pacotes (NuGet e PowerShell)...
echo -------------------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.208 -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
call :checa "Provedor NuGet / TLS 1.2"

:: ===================================================================
echo.
echo [2/14] Atualizando Repositorios e Fontes de Aplicativos (winget)...
echo -------------------------------------------------------------------
where winget >nul 2>&1
if errorlevel 1 (
    echo winget nao localizado neste sistema - Etapa ignorada.
    call :log "[2/14] winget nao localizado - PULADO"
    set /a SKIP_COUNT+=1
) else (
    winget source update >> "%LOGFILE%" 2>&1
    call :checa "Atualizacao do Gerenciador Winget"
)

:: ===================================================================
echo.
echo [3/14] Atualizando Aplicativos Instalados (winget upgrade)...
echo -------------------------------------------------------------------
where winget >nul 2>&1
if errorlevel 1 (
    echo winget nao localizado - Etapa ignorada.
    call :log "[3/14] winget nao localizado - PULADO"
    set /a SKIP_COUNT+=1
) else (
    winget upgrade --all --include-unknown --accept-source-agreements --accept-package-agreements --silent >> "%LOGFILE%" 2>&1
    call :checa "Atualizacao de Aplicativos em Segundo Plano"
)

:: ===================================================================
echo.
echo [4/14] Gerenciando e Instalando Atualizacoes de Seguranca do Windows...
echo -------------------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (-not (Get-Module -ListAvailable -Name PSWindowsUpdate)) { Install-Module PSWindowsUpdate -Force -AllowClobber -Scope CurrentUser -ErrorAction SilentlyContinue }; Import-Module PSWindowsUpdate -ErrorAction SilentlyContinue; Add-WUServiceManager -MicrosoftUpdate -Confirm:$false -ErrorAction SilentlyContinue; Get-WindowsUpdate -AcceptAll -Install -IgnoreReboot -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
call :checa "Windows Update / Modulo PSWindowsUpdate"

:: ===================================================================
echo.
echo [5/14] Diagnosticando Saude da Imagem do Sistema (DISM ScanHealth)...
echo -------------------------------------------------------------------
DISM /Online /Cleanup-Image /ScanHealth >> "%LOGFILE%" 2>&1
call :checa "Diagnostico da Imagem DISM"

:: ===================================================================
echo.
echo [6/14] Reparando Arquivos da Imagem do Windows (DISM RestoreHealth)...
echo -------------------------------------------------------------------
choice /C SN /T 10 /D S /M "Deseja reparar a imagem do Windows agora? (Inicio aut. em 10s)"
if errorlevel 2 (
    echo Etapa pulada pelo usuario.
    call :log "[6/14] DISM RestoreHealth - PULADO"
    set /a SKIP_COUNT+=1
) else (
    DISM /Online /Cleanup-Image /RestoreHealth >> "%LOGFILE%" 2>&1
    call :checa "Reparo da Imagem DISM"
)

:: ===================================================================
echo.
echo [7/14] Verificando e Reparando Integridade do Sistema (SFC)...
echo -------------------------------------------------------------------
sfc /scannow >> "%LOGFILE%" 2>&1
call :checa "Integridade dos Arquivos de Sistema (SFC)"

:: ===================================================================
echo.
echo [8/14] Otimizacao e Verificacao do Disco Rigido / SSD (chkdsk)...
echo -------------------------------------------------------------------
choice /C SN /T 10 /D S /M "Deseja executar a verificacao rapida do disco? (Inicio aut. em 10s)"
if errorlevel 2 (
    echo Etapa pulada pelo usuario.
    call :log "[8/14] chkdsk - PULADO"
    set /a SKIP_COUNT+=1
) else (
    chkdsk C: /scan >> "%LOGFILE%" 2>&1
    call :checa "Verificacao de Superficie do Disco (chkdsk)"
)

:: ===================================================================
echo.
echo [9/14] Atualizando Inteligencia de Afeccoes e Escaneamento (Defender)...
echo -------------------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Update-MpSignature -ErrorAction SilentlyContinue; Start-MpScan -ScanType QuickScan -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
call :checa "Protecao contra Afeccoes (Defender)"

:: ===================================================================
echo.
echo [10/14] Limpeza Profunda de Cache, Temp e Logs Antigos...
echo -------------------------------------------------------------------
echo [-] Limpando Temp do Usuario e Sistema...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item -Path $env:TEMP\* -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item -Path 'C:\Windows\Temp\*' -Recurse -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
echo [-] Limpando Cache do Prefetch...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item -Path 'C:\Windows\Prefetch\*' -Recurse -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
echo [-] Limpando Cache de Download do Windows Update...
net stop wuauserv >> "%LOGFILE%" 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item -Path 'C:\Windows\SoftwareDistribution\Download\*' -Recurse -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
net start wuauserv >> "%LOGFILE%" 2>&1
echo [-] Limpando Relatorios de Erro do Windows (WER)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item -Path 'C:\ProgramData\Microsoft\Windows\WER\*' -Recurse -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
call :log "[10/14] Limpeza Profunda de Arquivos Temporarios Concluida"
set /a OK_COUNT+=1

:: ===================================================================
echo.
echo [11/14] Otimizacao Avan�ada de Rede, DNS e Winsock...
echo -------------------------------------------------------------------
echo [-] Flush de DNS...
ipconfig /flushdns >> "%LOGFILE%" 2>&1
echo [-] Resetando Pilha TCP/IP e Winsock...
netsh int ip reset >> "%LOGFILE%" 2>&1
netsh winsock reset >> "%LOGFILE%" 2>&1
call :log "[11/14] Otimizacao de Rede Concluida"
set /a OK_COUNT+=1

:: ===================================================================
echo.
echo [12/14] Otimizacao e Defragmentacao / TRIM de Unidades de Armazenamento...
echo -------------------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Optimize-Volume -DriveLetter C -Defrag -Verbose" >> "%LOGFILE%" 2>&1
call :checa "Otimizacao / TRIM de Disco C:"

:: ===================================================================
echo.
echo [13/14] Compagina��o e Compactacao de Componentes do Windows (DISM)...
echo -------------------------------------------------------------------
DISM /Online /Cleanup-Image /StartComponentCleanup /ResetBase >> "%LOGFILE%" 2>&1
call :checa "Compactacao e Limpeza de Componentes Antigos (WinSxS)"

:: ===================================================================
echo.
echo [14/14] Limpeza da Lixeira do Sistema...
echo -------------------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Clear-RecycleBin -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
call :checa "Limpeza Completa da Lixeira"

:: ===================================================================
:: Resumo Final e Relatorio
:: ===================================================================
echo.
echo ===================================================================
echo             OTIMIZACAO CONCLUIDA COM SUCESSO!
echo ===================================================================
echo.
echo  Tarefas Concluidas com Sucesso : %OK_COUNT%
echo  Tarefas com Falha ou Aviso    : %FAIL_COUNT%
echo  Tarefas Ignoradas / Puladas  : %SKIP_COUNT%
echo.
echo Log detalhado disponivel em:
echo   %LOGFILE%
echo.
call :log "===================================================================="
call :log "  FIM DA EXECUCAO: %date% %time% | OK=%OK_COUNT% | FALHAS=%FAIL_COUNT% | PULADAS=%SKIP_COUNT%"
call :log "===================================================================="
echo Recomenda-se reiniciar o sistema para consolidar as melhorias.
echo.
pause
exit /B 0

:: ===================================================================
:: Subrotinas
:: ===================================================================
:checa
if errorlevel 1 (
    echo [FALHA / AVISO] %~1
    call :log "[FALHOU] %~1 (Codigo: %errorlevel%)"
    set /a FAIL_COUNT+=1
) else (
    echo [OK] %~1
    call :log "[OK] %~1"
    set /a OK_COUNT+=1
)
exit /B 0

:log
echo %~1 >> "%LOGFILE%"
exit /B 0
