@echo off
:: ===================================================================
:: Otimizador 2026 - Manutencao Completa e Profunda do PC
:: Versao aprimorada: log em arquivo, tratamento de erros, confirmacao
:: nas etapas demoradas e resumo final dinamico.
:: ===================================================================

setlocal enabledelayedexpansion

:: -------------------------------------------------------------
:: Elevar para administrador, se necessario
:: -------------------------------------------------------------
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' neq '0' (
    echo.
    echo Este script requer permissoes de administrador!
    echo Solicitando acesso...
    echo.
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "cmd.exe", "/c cd /d ""%~dp0"" && ""%~s0"" %*", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
cd /d "%~dp0"

:: -------------------------------------------------------------
:: Configuracao de log e contadores
:: -------------------------------------------------------------
set "LOGDIR=%~dp0Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set "DT=%%I"
if not defined DT (
    set "DT=%date:~-4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%"
    set "DT=!DT: =0!"
)
set "LOGFILE=%LOGDIR%\otimizador_%DT%.log"

set /a OK_COUNT=0
set /a FAIL_COUNT=0
set /a SKIP_COUNT=0
set "RESUMO="
set "STARTTIME=%time%"

call :log "===================================================================="
call :log "  OTIMIZADOR 2026 - MANUTENCAO COMPLETA DO PC - INICIO: %date% %time%"
call :log "===================================================================="

cls
echo.
echo ===================================================================
echo           OTIMIZADOR 2026 - MANUTENCAO COMPLETA DO PC
echo ===================================================================
echo.
echo O log completo desta execucao sera salvo em:
echo   %LOGFILE%
echo.
echo Algumas etapas (verificacao de disco, reparo de imagem do Windows)
echo podem demorar bastante. Voce pode pular etapas individuais se quiser.
echo.
pause

:: ===================================================================
echo.
echo [1/12] Atualizando Provedor de Pacotes (NuGet)...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Install-PackageProvider NuGet -Force -ErrorAction Stop" >> "%LOGFILE%" 2>&1
call :checa "Provedor NuGet"

:: ===================================================================
echo.
echo [2/12] Atualizando Fontes de Aplicativos (winget)...
echo -------------------------------------------------------
where winget >nul 2>&1
if errorlevel 1 (
    echo winget nao encontrado neste sistema - etapa ignorada.
    call :log "[2/12] winget nao encontrado - PULADO"
    set /a SKIP_COUNT+=1
) else (
    winget source update >> "%LOGFILE%" 2>&1
    call :checa "Fontes do winget"
)

:: ===================================================================
echo.
echo [3/12] Procurando Atualizacoes de Aplicativos (winget upgrade)...
echo -------------------------------------------------------
where winget >nul 2>&1
if errorlevel 1 (
    echo winget nao encontrado - etapa ignorada.
    call :log "[3/12] winget nao encontrado - PULADO"
    set /a SKIP_COUNT+=1
) else (
    winget upgrade --all --include-unknown --accept-source-agreements --accept-package-agreements >> "%LOGFILE%" 2>&1
    call :checa "Atualizacao de aplicativos"
)

:: ===================================================================
echo.
echo [4/12] Atualizando Windows e Drivers (PSWindowsUpdate)...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (-not (Get-Module -ListAvailable -Name PSWindowsUpdate)) { Install-Module PSWindowsUpdate -Force -AllowClobber -ErrorAction Stop }; Import-Module PSWindowsUpdate -ErrorAction Stop; Add-WUServiceManager -MicrosoftUpdate -Confirm:$false -ErrorAction Stop; Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -ErrorAction Stop" >> "%LOGFILE%" 2>&1
call :checa "Windows Update / Drivers"

:: ===================================================================
echo.
echo [5/12] Verificando Saude da Imagem do Windows (DISM ScanHealth)...
echo -------------------------------------------------------
DISM /Online /Cleanup-Image /ScanHealth >> "%LOGFILE%" 2>&1
call :checa "DISM ScanHealth"

:: ===================================================================
echo.
echo [6/12] Reparando Imagem do Windows (DISM RestoreHealth)...
echo -------------------------------------------------------
echo Esta etapa pode demorar varios minutos.
choice /C SN /M "Deseja executar o reparo da imagem do Windows agora"
if errorlevel 2 (
    echo Etapa pulada pelo usuario.
    call :log "[6/12] DISM RestoreHealth - PULADO PELO USUARIO"
    set /a SKIP_COUNT+=1
) else (
    DISM /Online /Cleanup-Image /RestoreHealth >> "%LOGFILE%" 2>&1
    call :checa "DISM RestoreHealth"
)

:: ===================================================================
echo.
echo [7/12] Verificando Integridade dos Arquivos do Sistema (SFC)...
echo -------------------------------------------------------
sfc /scannow >> "%LOGFILE%" 2>&1
call :checa "SFC scannow"

:: ===================================================================
echo.
echo [8/12] Verificando Disco e Setores Ruins (chkdsk)...
echo -------------------------------------------------------
echo Esta etapa pode demorar bastante em discos grandes.
choice /C SN /M "Deseja executar a verificacao de disco agora"
if errorlevel 2 (
    echo Etapa pulada pelo usuario.
    call :log "[8/12] chkdsk - PULADO PELO USUARIO"
    set /a SKIP_COUNT+=1
) else (
    chkdsk C: /scan >> "%LOGFILE%" 2>&1
    call :checa "chkdsk /scan"
)

:: ===================================================================
echo.
echo [9/12] Atualizando Antivirus e Verificando Ameacas...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Update-MpSignature -ErrorAction Stop" >> "%LOGFILE%" 2>&1
call :checa "Atualizacao de assinaturas do Defender"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-MpScan -ScanType QuickScan -ErrorAction Stop" >> "%LOGFILE%" 2>&1
call :checa "Verificacao rapida do Defender"

:: ===================================================================
echo.
echo [10/12] Limpando Arquivos Temporarios e Cache...
echo -------------------------------------------------------
echo Limpando TEMP do usuario...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path $env:TEMP -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
echo Limpando C:\Windows\Temp...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path 'C:\Windows\Temp' -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
echo Limpando Prefetch...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path 'C:\Windows\Prefetch' -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
echo Limpando cache do Windows Update (SoftwareDistribution)...
net stop wuauserv >> "%LOGFILE%" 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path 'C:\Windows\SoftwareDistribution\Download' -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue" >> "%LOGFILE%" 2>&1
net start wuauserv >> "%LOGFILE%" 2>&1
echo Limpando Cache DNS...
ipconfig /flushdns >> "%LOGFILE%" 2>&1
echo Arquivos temporarios limpos.
call :log "[10/12] Limpeza de temporarios concluida"
set /a OK_COUNT+=1

:: ===================================================================
echo.
echo [11/12] Limpando Cache de Atualizacoes Antigas (Component Cleanup)...
echo -------------------------------------------------------
DISM /Online /Cleanup-Image /StartComponentCleanup >> "%LOGFILE%" 2>&1
call :checa "DISM StartComponentCleanup"

:: ===================================================================
echo.
echo [12/12] Esvaziando Lixeira...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Clear-RecycleBin -Force -ErrorAction Stop" >> "%LOGFILE%" 2>&1
call :checa "Esvaziar Lixeira"

:: ===================================================================
:: Resumo final
:: ===================================================================
echo.
echo ===================================================================
echo             MANUTENCAO FINALIZADA
echo ===================================================================
echo.
echo Etapas concluidas com sucesso : %OK_COUNT%
echo Etapas com falha               : %FAIL_COUNT%
echo Etapas puladas                 : %SKIP_COUNT%
echo.
echo Log completo salvo em:
echo   %LOGFILE%
echo.
if %FAIL_COUNT% GTR 0 (
    echo ATENCAO: uma ou mais etapas falharam. Consulte o log acima para detalhes.
    echo.
)
echo RECOMENDACAO: Reinicie o computador agora para aplicar todas as mudancas!
echo.
echo ===================================================================
call :log "===================================================================="
call :log "  FIM DA EXECUCAO: %date% %time% - OK=%OK_COUNT% FALHAS=%FAIL_COUNT% PULADAS=%SKIP_COUNT%"
call :log "===================================================================="
echo.
pause
exit /B 0

:: ===================================================================
:: Funcoes auxiliares
:: ===================================================================

:checa
:: Verifica o errorlevel do ultimo comando e atualiza contadores/log
if errorlevel 1 (
    echo [FALHOU] %~1
    call :log "[FALHOU] %~1 (codigo %errorlevel%)"
    set /a FAIL_COUNT+=1
) else (
    echo [OK] %~1
    call :log "[OK] %~1"
    set /a OK_COUNT+=1
)
exit /B 0

:log
echo %~1 >> "%LOGFILE%"
exit /B 0
